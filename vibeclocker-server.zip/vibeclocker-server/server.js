const path = require('path');
const express = require('express');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');

const PROD = process.env.NODE_ENV === 'production';
const SECRET = process.env.JWT_SECRET || (PROD ? null : 'dev-only-secret-change-me');
if (!SECRET) { console.error('Set the JWT_SECRET environment variable.'); process.exit(1); }

// ---- Database -------------------------------------------------------------
const db = new Database(process.env.DB_PATH || path.join(__dirname, 'vibeclocker.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS essays (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  prompt TEXT,
  body TEXT NOT NULL,
  overall REAL,
  scores TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_essays_user ON essays(user_id, created_at);
`);

// ---- App ------------------------------------------------------------------
const app = express();
if (PROD) app.set('trust proxy', 1);
app.use(express.json({ limit: '300kb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 30, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Too many attempts. Please wait a few minutes and try again.' } });

const cookieOpts = { httpOnly: true, sameSite: 'lax', secure: PROD, maxAge: 7 * 24 * 60 * 60 * 1000 };
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', 10);
const EMAIL_RE = /^\S+@\S+\.\S+$/;

const publicUser = u => ({ name: u.name, email: u.email });
const issue = (res, id) => res.cookie('token', jwt.sign({ id }, SECRET, { expiresIn: '7d' }), cookieOpts);

function requireAuth(req, res, next) {
  try {
    const { id } = jwt.verify(req.cookies.token || '', SECRET);
    const user = db.prepare('SELECT id, name, email FROM users WHERE id = ?').get(id);
    if (!user) throw new Error('gone');
    req.user = user;
    next();
  } catch (e) {
    res.status(401).json({ error: 'Please log in.' });
  }
}

// ---- Auth -----------------------------------------------------------------
app.post('/api/signup', authLimiter, async (req, res) => {
  const name = String(req.body.name || '').trim().slice(0, 80);
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (!name) return res.status(400).json({ error: 'Enter your name to sign up.' });
  if (!EMAIL_RE.test(email) || email.length > 200) return res.status(400).json({ error: 'Enter a valid email address.' });
  if (password.length < 8 || password.length > 200) return res.status(400).json({ error: 'Use a password with 8 to 200 characters.' });
  if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email)) return res.status(409).json({ error: 'That email already has an account. Try logging in.' });
  const hash = await bcrypt.hash(password, 10);
  const info = db.prepare('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)').run(name, email, hash);
  issue(res, info.lastInsertRowid);
  res.status(201).json({ user: { name, email } });
});

app.post('/api/login', authLimiter, async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  const ok = await bcrypt.compare(password, user ? user.password_hash : DUMMY_HASH);
  if (!user || !ok) return res.status(401).json({ error: 'Incorrect email or password.' });
  issue(res, user.id);
  res.json({ user: publicUser(user) });
});

app.post('/api/logout', (req, res) => { res.clearCookie('token', cookieOpts); res.json({ ok: true }); });
app.get('/api/me', requireAuth, (req, res) => res.json({ user: publicUser(req.user) }));

// ---- Essays ---------------------------------------------------------------
app.post('/api/essays', requireAuth, (req, res) => {
  const { prompt, text, overall, scores } = req.body || {};
  if (typeof text !== 'string' || !text.trim()) return res.status(400).json({ error: 'Essay text is required.' });
  if (text.length > 50000) return res.status(400).json({ error: 'Essay is over 50,000 characters.' });
  const total = Number(overall);
  if (!(total >= 0 && total <= 5)) return res.status(400).json({ error: 'Invalid score.' });
  const info = db.prepare('INSERT INTO essays (user_id, prompt, body, overall, scores) VALUES (?, ?, ?, ?, ?)')
    .run(req.user.id, typeof prompt === 'string' ? prompt.slice(0, 500) : null, text, total, JSON.stringify(Array.isArray(scores) ? scores.slice(0, 8) : []));
  res.status(201).json({ id: info.lastInsertRowid });
});

app.get('/api/essays', requireAuth, (req, res) => {
  const rows = db.prepare('SELECT id, prompt, overall, scores, created_at, substr(body, 1, 140) AS preview FROM essays WHERE user_id = ? ORDER BY id DESC LIMIT 50').all(req.user.id);
  res.json({ essays: rows.map(r => ({ ...r, scores: JSON.parse(r.scores || '[]') })) });
});

app.get('/api/essays/:id', requireAuth, (req, res) => {
  const row = db.prepare('SELECT id, prompt, body, overall, scores, created_at FROM essays WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!row) return res.status(404).json({ error: 'Essay not found.' });
  res.json({ essay: { ...row, scores: JSON.parse(row.scores || '[]') } });
});

app.delete('/api/essays/:id', requireAuth, (req, res) => {
  db.prepare('DELETE FROM essays WHERE id = ? AND user_id = ?').run(req.params.id, req.user.id);
  res.json({ ok: true });
});

app.delete('/api/account', requireAuth, (req, res) => {
  db.prepare('DELETE FROM users WHERE id = ?').run(req.user.id);
  res.clearCookie('token', cookieOpts);
  res.json({ ok: true });
});

// ---- Errors ---------------------------------------------------------------
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found.' }));
app.use((err, req, res, next) => {
  if (err.type === 'entity.too.large') return res.status(413).json({ error: 'That request is too large.' });
  if (err instanceof SyntaxError) return res.status(400).json({ error: 'Invalid request.' });
  console.error(err);
  res.status(500).json({ error: 'Something went wrong on our side. Try again.' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log('VibeClocker running on http://localhost:' + PORT));
