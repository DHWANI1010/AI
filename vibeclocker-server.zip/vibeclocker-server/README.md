# VibeClocker with a server

Accounts (bcrypt-hashed passwords, httpOnly cookie sessions) and saved essays with scores are stored in SQLite.

## Run locally
    npm install
    npm start        # http://localhost:3000

## Deploy (needs a host that runs Node and has a persistent disk)
Netlify Drop and GitHub Pages can't run this server. Use Render, Railway or Fly.io.
1. Push this folder to a GitHub repository.
2. Create a Web Service from it. Build command: `npm install`. Start command: `npm start`.
3. Set environment variables:
   - `NODE_ENV=production`
   - `JWT_SECRET=` a long random string (for example from `openssl rand -hex 32`)
   - `DB_PATH=/data/vibeclocker.db`
4. Attach a persistent disk or volume mounted at `/data`. Without it, the database resets on every deploy.
5. Serve over HTTPS (the host does this for you).

## API
POST /api/signup, POST /api/login, POST /api/logout, GET /api/me,
POST /api/essays, GET /api/essays, GET /api/essays/:id, DELETE /api/essays/:id, DELETE /api/account
